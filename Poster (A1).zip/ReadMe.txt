ScientificPosterTemplate - version 1.0

This package provide a framework to create a scientific poster.


Author
------
gaelbn.wp@gmail.com


Licence
-------
Creative Commons - Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0) - http://creativecommons.org/licenses/by-nc-sa/4.0/deed.en


Folder contents
---------------
ReadMe.txt
ScientificPosterTemplate.sty
PosterExampleA0.tex
PosterExampleA0.pdf
PosterExampleA1.tex
PosterExampleA1 - copie.pdf
references.bib
figures/
   default_image.png
   default_image_2.png
   logos/
      logo.png


Use
---
The package is very easy to use.
Two poster sizes are available, A0 (the most common format during conferences) and A1. For each format, a .tex file is provided as a basis for the poster.
To use the style file provided, just add in the tex header file the following line: \usepackage[opt1,opt2]{ScientificPosterTemplate}.
Option 1 (opt1) corresponds to the color format to use (for color defined in "ScientificPosterTemplate.sty", and can be : RGB, Coated or Uncoated.
Option 2 (opt2) is the poster format used (A0 or A1), it sets the size of some spaces, figure legends and references in the references part.

The natbib package is used for the bibliography, with a superscript number for the style of references ("super" option).

The different sizes of texts were set to be in agreement with most instructions that can be found in the guidelines.


Known bugs or warning
---------------------
none
